from setuptools import setup

setup(
    name='miniros_motor_controller',
    version='1.1.0a',
    description='miniros package',
    license='MIT',
    packages=['miniros_motor_controller', 'miniros_motor_controller.source'],
    keywords=[],
)
