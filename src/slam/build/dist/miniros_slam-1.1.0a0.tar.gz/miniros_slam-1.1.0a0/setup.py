from setuptools import setup

setup(
    name='miniros_slam',
    version='1.1.0a',
    description='miniros package',
    license='MIT',
    packages=['miniros_slam', 'miniros_slam.source'],
    keywords=[],
)
