from setuptools import setup

setup(
    name='miniros_goal_manager',
    version='1.1.0a',
    description='miniros package',
    license='MIT',
    packages=['miniros_goal_manager', 'miniros_goal_manager.source'],
    keywords=[],
)
