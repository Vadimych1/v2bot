from setuptools import setup

setup(
    name='miniros_path_planner',
    version='1.1.0a',
    description='miniros package',
    license='MIT',
    packages=['miniros_path_planner', 'miniros_path_planner.source'],
    keywords=[],
)
